/**************************************************************
 Target MCU & clock speed: ATmega328P @ 1Mhz internal
 Name    : words.c
 Author  : Insoo Kim (insoo@hotmail.com)
 Created : May 17, 2015
 Updated : May 24, 2015

 Description: Get system compile time & date and display on LCD 2*16
    Button toggling to turn on or off the backlight of LCD

 HEX size[Byte]:

 Ref:
    Donald Weiman    (weimandn@alfredstate.edu)
    http://web.alfredstate.edu/weimandn/programming/lcd/ATmega328/LCD_code_gcc_4d.html
 *****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include "defines.h"

uint8_t wd=0;

// New words
uint8_t words000[10][2][16] =
    {
      {//0 "1234512345123456" "1234512345123456"
         //"petrified",       "cause2bcmStnlike"
           "f(DNA)>f(RNA)",   "chemical stblty"
      },
      {//1 "1234512345123456" "1234512345123456"
         //"arid",            "lckgSuffWtr/Rain"
           "gene region",     "cdngRegIntergen"
      },
      {//2 "1234512345123456" "1234512345123456"
         //"enliven",         "hgtn/intensify"
           "chromosome",      "gene repository"
      },
      {//3"1234512345123456" "1234512345123456"
         //"lurch",           "mv abruptly"
           "genome struc",    "unknown field"
      },
      {//4 "1234512345123456" "1234512345123456"
         //"oblivious to",     "lckgCnscsAwrnOf"
           "gene# genomeSize", "nonPrpt2LfCmlx"
      },
      {//5 "1234512345123456"   "1234512345123456"
         //"wtn a whisker of",  "extremelyClose 2"
           "homoSapiens",       "39Kgene/3.2Bnctp"
      },
      {//6 "1234512345123456"   "1234512345123456"
         //"colloid",           "mixWpropBtSolSus"
           "1gene-nProtein",    "diffGeneDensity"
      },
      {//7 "1234512345123456"   "1234512345123456"
         //"reticent",          "disclined2talk"
           "transcription",     "DNA->RNA@ncls"
      },
      {//8 "1234512345123456"   "1234512345123456"
         //"pry~apart",         "force2getSthOpen"
           "translation",       "ncacd2proteinNFO"
      },
      {//9 "1234512345123456"   "1234512345123456"
         //"esoteric",          "cnfnd2onyEnlgtnd"
           "ncltd triplet",     "1codon->1amnAcd"
         //"ribosome",          "triplet(codon) + tRNA"
      },
    }; //words000[10][2][16]

uint8_t words001[10][2][16] =
    {
      {//0 "1234512345123456" "1234512345123456"
         //"snag",              "hiddenObstacle"
           "mom",              "-9914-"
      },
      {//1 "1234512345123456" "1234512345123456"
         //"mission-agnostic",  "genApplicable"
         "TJ",  "-4024-2946"
      },
      {//2 "1234512345123456" "1234512345123456"
           //"deep-stedCulture","fracturedRltnshp"
            "SunAh203-1503",    "032-518-2176"
      },
      {//3"1234512345123456" "1234512345123456"
         //"tumult",           "loudCnfsdNseByMs"
         "SunAhMobile",    "017-361-0327"
      },
      {//4 "1234512345123456" "1234512345123456"
        //"sobering",           "tending2mkSober"
        "PHS",           "-5090-9139"
      },
      {//5 "1234512345123456"   "1234512345123456"
         //"miscarrage",          "brthBbyAlrdDd@Wm"
           "SJ_FlyzKssk@han",   "-4711-9816"
      },
      {//6 "1234512345123456"   "1234512345123456"
           //"class-actnLwSt",    "lawSuitTogether"
           "JMH",               "-4312-2112"
      },
      {//7 "1234512345123456"   "1234512345123456"
           //"blister",           "fluidPocket"
           "JK_jk1024@naver",   "-9249-4113"
      },
      {//8 "1234512345123456"   "1234512345123456"
           //"titter",            "laughQuietNrvsly"
           "YS_yong2b@naver",      "055-587-4292"
      },
      {//9 "1234512345123456"   "1234512345123456"
           //"line cook",         "a cook inKitchen"
           "YS@Home",           "055-232-8027"
      },
    }; //words001[10][2][16]
