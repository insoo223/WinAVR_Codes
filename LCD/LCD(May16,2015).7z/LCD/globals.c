/**************************************************************
 Target MCU & clock speed: ATmega328P @ 1Mhz internal
 Name    : globals.c
 Complete C modules of this project: main.c globals.c intrpt.c, strFunc.c
 Complete custom headers of this project: defines.h externs.h
 Author  : Insoo Kim (insoo@hotmail.com)
 Created : May 15, 2015
 Updated : May 16, 2015

 Description: Get system compile time & date and display on LCD 2*16
    Button toggling to turn on or off the backlight of LCD

 HEX size[Byte]: 3208 out of 32K (all modules built together)

 Ref:
    Donald Weiman    (weimandn@alfredstate.edu)
    http://web.alfredstate.edu/weimandn/programming/lcd/ATmega328/LCD_code_gcc_4d.html
 *****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include "defines.h"
uint8_t hour=0, min=0, sec=0;
uint8_t year=0, month=0, date=0;
uint8_t monthEndDate, day=6;

// Program ID
uint8_t program_author[]   = "Insoo Kim     ";
uint8_t program_version[]  = "LCD-ATmega328p";
uint8_t program_date[]     = "May 12, 2015  ";

