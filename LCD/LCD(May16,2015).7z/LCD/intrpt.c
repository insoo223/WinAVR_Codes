/**************************************************************
 Target MCU & clock speed: ATmega328P @ 1Mhz internal
 Name    : intrpt.c
 Complete C modules of this project: main.c globals.c intrpt.c, strFunc.c
 Complete custom headers of this project: defines.h externs.h
 Author  : Insoo Kim (insoo@hotmail.com)
 Created : May 15, 2015
 Updated : May 16, 2015

 Description: Get system compile time & date and display on LCD 2*16
    Button toggling to turn on or off the backlight of LCD

 HEX size[Byte]: 3208 out of 32K (all modules built together)

 Ref:
    Donald Weiman    (weimandn@alfredstate.edu)
    http://web.alfredstate.edu/weimandn/programming/lcd/ATmega328/LCD_code_gcc_4d.html
 *****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/sleep.h>
#include "externs.h"
#include "defines.h"
#include <util/delay.h>

extern uint8_t hour, min, sec;
extern uint8_t year, month, date;
extern uint8_t monthEndDate, day;

extern void lcd_testClock();

//-----------------------------------
ISR(WDT_vect)
{
    //PORTB |= _BV(PB4);
    sec += 8;
    if (sec >= 60)
    {
        sec%=60;
        min++;
        sec += 2;
    }
    if (min >= 60)
    {
        min=0;
        hour++;
    }
    if (hour >= 24)
    {
        hour=0;
        date++;
        day++;
        if (day >= 7)
            day %= 7;
    }
    switch (month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            monthEndDate = 31;
            break;
        case 2:
            monthEndDate = 28;
            break;
        default:
            monthEndDate = 30;
    }//switch (month)

    if (date > monthEndDate)
    {
        date=1;
        month++;
    }

    if (month > 12)
    {
        month=1;
        year++;
    }
    lcd_testClock();
    //PORTB &= ~_BV(PB4);
}//ISR(WDT_vect)

//-----------------------------------
void WDT_Init(void)
{
    //disable interrupts
    cli();
    //MCUSR = 0;

    wdt_disable();
    //set up WDT interrupt
    //WDTCSR = _BV(WDCE)|_BV(WDE);
    //Start watchdog timer with 4s prescaller
    //WDTCSR |= _BV(WDIE)|_BV(WDE)|_BV(WDP3);
    //WDTCSR |= _BV(WDIE)| _BV(WDP3);
    //WDTCSR |= _BV(WDIE)|_BV(WDE)|_BV(WDP2) | _BV(WDP1); // 1s

    //reset watchdog
    wdt_reset();
    wdt_enable(WDTO_500MS);
    //Enable global interrupts
    sei();
}//WDT_Init

void initINT()
{
    cli();
    //**** PC(Pin Change) interrupt setting
    // enable PC INT
    //GIMSK |= _BV(PCIE);  //Enable PC interrupt
    // Enable pin change interrupt for PB3
    //PCMSK |= _BV(PCINT3);
    //PCMSK |= _BV(startPin);

    //**** WDT interrupt setting
    //set prescale timer
    //DS: ch10.9.2 table10.2
    //set up WDT interrupt
    WDTCSR |= _BV(WDCE)| _BV(WDE);
    //WDTCSR = _BV(WDIE) | _BV(WDP3) | _BV(WDP0); // 8s
    WDTCSR = _BV(WDIE) | _BV(WDP3); // 4s
    //WDTCSR = _BV(WDIE) | _BV(WDP2) | _BV(WDP0); // 0.5s


    //wdt_reset();
    //enalbe global interrupt
    sei();


}//initINT

/*
Utmost(!) help to get the WDT of ATmega328p work
http://elegantcircuits.com/2014/10/14/introduction-to-the-avr-watchdog-timer/
*/
void check_wdt(void)
{
    // If a reset was caused by the Watchdog Timer...
    if(MCUSR & _BV(WDRF))
    {
        // Clear the WDT reset flag
        MCUSR &= ~_BV(WDRF);
        // Enable the WD Change Bit
        WDTCSR |= (_BV(WDCE) | _BV(WDE));
        // Disable the WDT
        WDTCSR = 0x00;
    }
}//check_wdt

void setup_wdt(void){
// Set up Watch Dog Timer for Inactivity
    // Enable the WD Change Bit
    // Enable WDT interrupt
    WDTCSR |= _BV(WDCE) | _BV(WDE);

    // Set Timeout to ~8 seconds
    WDTCSR = _BV(WDIE) | _BV(WDP3) | _BV(WDP0); // 8s
    // Set Timeout to ~1 seconds
    //WDTCSR =   _BV(WDIE) |  _BV(WDP2) | _BV(WDP1);
    // Set Timeout to ~500 ms
    //WDTCSR =   _BV(WDIE) | _BV(WDP2);
}//setup_wdt

void init_devices(void){
    //stop errant interrupts until set up
    cli(); //disable all interrupts

    //timer0_init();

    MCUCR = 0x00;
    EICRA = 0x00; //extended ext ints
    EIMSK = 0x00;

    TIMSK0 = 0x02; //timer 0 interrupt sources

    PRR = 0x00; //power controller
    sei(); //re-enable interrupts
    //all peripherals are now initialized
}
