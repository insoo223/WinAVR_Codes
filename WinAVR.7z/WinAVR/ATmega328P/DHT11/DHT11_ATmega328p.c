/**************************************************************
 Target MCU & internal clock speed: ATmega328p @ 1Mhz
 Name    : DHT11_ATmega328p.c
 Author  : Insoo Kim (insoo@hotmail.com)
 Date    : May 13, 2015

 Description: Read temperature & humidity from DHT11 sensor,
 and display T&H on two digits 7 segment LEDs for around 1 second each, continuously.
 HEX size[Byte]: 728 out of 1024

 Ref:
 ** Written for and tested with a custom board with ATtiny13A run on 9.6Mhz int osc
 ** Functions regarding DHT11, i.e."dht_getdata", are refered from the following link of David Gironi.
 ** But, specific time delays have been measured using Hantek USB digital oscilloscope (6022BE) and modified to fit into my custom ATtiny13A board.
 ** http://davidegironi.blogspot.kr/2013/02/reading-temperature-and-humidity-on-avr.html#.VSRiHSlCNSV
 *****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "../dht/dht.h"


#define DHT11_PIN PB3
#define debug_PIN PB4

//Define functions
//======================
void ioinit(void);
int8_t dht_getdata(int8_t *, int8_t *);


void ioinit (void);
void show7seg(unsigned char);
void getDHT11(void);

//----------------------------------------------------------
void getDHT11(void)
{

    int8_t temperature = 0;
    int8_t humidity = 0;

    ioinit();


    if(dht_gettemperaturehumidity(&temperature, &humidity) != -1)
    {
        ;
    }
    else
    {
        ;
    }

    _delay_ms(90);
}//getDHT11

//----------------------------------------------------------
void ioinit (void)
{
    //DDRB  = 0xff; //1 = output, 0 = input

    DDRB &= ~_BV(DHT11_PIN); //input
    DDRB |= _BV(debug_PIN); //output

    //PORTB = 0x00;
}//ioinit


/*
 * get data from sensor
 */
//----------------------------------------------------------
int8_t dht_getdata(int8_t *temperature, int8_t *humidity)
{
    uint8_t bits[5];
    uint8_t i,j = 0;

    //memset(bits, 0, sizeof(bits));

    //reset port
    DHT_DDR |= (1<<DHT_INPUTPIN); //output
    DHT_PORT |= (1<<DHT_INPUTPIN); //high

    //_delay_ms(15); // 124ms by real measurement of OSC
    _delay_ms(200);

    //send request for at least 18ms from MCU
    DHT_PORT &= ~(1<<DHT_INPUTPIN); //low
    //_delay_ms(3);//25ms by real measurement of OSC
    _delay_ms(36);

    //check start condition 1
    if((DHT_PIN & (1<<DHT_INPUTPIN)))
    {
        *temperature = 91;
        return -1;
    }

            PORTB |= _BV(debug_PIN);
   _delay_us(160);
            PORTB &= ~_BV(debug_PIN);

    DHT_PORT |= (1<<DHT_INPUTPIN); //high
    _delay_us(160);
    //check start condition 2
    if(!(DHT_PIN & (1<<DHT_INPUTPIN)))
    {
        *temperature = 92;
        return -1;
    }

    DHT_DDR &= ~(1<<DHT_INPUTPIN); //input

    //DHT_PORT |= _BV(debug_PIN); //high debug pin
    //_delay_us(20);
    //DHT_PORT &= ~_BV(debug_PIN); //low debug pin

    //read the data
    uint16_t timeoutcounter = 0;
    for (j=0; j<5; j++)
    { //read 5 byte
        uint8_t result=0;

        for(i=0; i<8; i++)
        {//read every bit
            timeoutcounter = 0;
            while(!(DHT_PIN & (1<<DHT_INPUTPIN)))
            { //wait for an high input (non blocking)
                timeoutcounter++;
                if(timeoutcounter > DHT_TIMEOUT)
                {
                    *temperature = 93;
                    return -1; //timeout
                }
            }

            //_delay_us(6); // this is critical time delay to read correct data
            //if input is high after 30 us, get result
            //PORTB |= _BV(debug_PIN);
            _delay_us(20);
            //PORTB &= ~_BV(debug_PIN);
            if(DHT_PIN & (1<<DHT_INPUTPIN))
                result |= (1<<(7-i));

            timeoutcounter = 0;
            while(DHT_PIN & (1<<DHT_INPUTPIN))
            { //wait until input get low (non blocking)
                timeoutcounter++;
                if(timeoutcounter > DHT_TIMEOUT)
                {
                    *temperature = 94;
                    return -1; //timeout
                }
            }
        }
        bits[j] = result;
    }

    //reset port
    DHT_DDR |= (1<<DHT_INPUTPIN); //output
    DHT_PORT |= (1<<DHT_INPUTPIN); //low
    _delay_ms(15);

    //check checksum
    if ((uint8_t)(bits[0] + bits[1] + bits[2] + bits[3]) == bits[4])
    {
        //return temperature and humidity
        if (bits[2] !=0)
        {
            *temperature = bits[2];
            *humidity = bits[0];
        }
        else
        {
            *temperature = 97;
            *humidity = 98;
        }

        return 0;
    }

    return -1;
}//dht_getdata

/*
 * get temperature
 */
//----------------------------------------------------------
int8_t dht_gettemperature(int8_t *temperature)
{
    int8_t humidity = 0;
    return dht_getdata(temperature, &humidity);
}//dht_gettemperature

/*
 * get humidity
 */
int8_t dht_gethumidity(int8_t *humidity)
{
    int8_t temperature = 0;
    return dht_getdata(&temperature, humidity);
}//dht_gethumidity

/*
 * get temperature and humidity
 */
//----------------------------------------------------------
int8_t dht_gettemperaturehumidity(int8_t *temperature, int8_t *humidity)
{
    return dht_getdata(temperature, humidity);
}//dht_gettemperaturehumidity



