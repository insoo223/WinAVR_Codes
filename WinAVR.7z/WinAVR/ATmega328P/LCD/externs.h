/**************************************************************
 Target MCU & clock speed: ATmega328P @ 1Mhz internal
 Name    : externs.h
 Complete C modules of this project: main.c globals.c intrpt.c, strFunc.c
 Complete custom headers of this project: defines.h externs.h
 Author  : Insoo Kim (insoo@hotmail.com)
 Created : May 15, 2015
 Updated : May 16, 2015

 Description: Get system compile time & date and display on LCD 2*16
    Button toggling to turn on or off the backlight of LCD

 HEX size[Byte]: 3208 out of 32K (all modules built together)

 Ref:
    Donald Weiman    (weimandn@alfredstate.edu)
    http://web.alfredstate.edu/weimandn/programming/lcd/ATmega328/LCD_code_gcc_4d.html
 *****************************************************************/

extern uint8_t program_author[];
extern uint8_t program_version[];
extern uint8_t program_date[];

extern int8_t dht_getdata(int8_t *, int8_t *);
extern int8_t dht_gettemperaturehumidity(int8_t *, int8_t *);
extern void ioinit (void);

extern uint8_t hour, min, sec;
extern uint8_t year, month, date;
extern uint8_t monthEndDate, day;

extern void WDT_Init(void);
extern void initINT(void);
extern void check_wdt(void);
extern void setup_wdt(void);
extern void init_devices(void);
extern void parseCompileTime(void);

